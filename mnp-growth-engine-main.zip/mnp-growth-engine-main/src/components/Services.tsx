import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Brain, 
  BarChart3, 
  Code, 
  Globe, 
  Shield, 
  Cloud,
  Settings,
  ArrowRight
} from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Brain,
      title: "Digital Advisory",
      description: "Strategic guidance to navigate your digital transformation journey with confidence and clarity."
    },
    {
      icon: BarChart3,
      title: "Applied Data & Analytics",
      description: "Transform raw data into actionable insights that drive business growth and innovation."
    },
    {
      icon: Code,
      title: "Application Development",
      description: "Custom applications built with modern technologies to solve your unique business challenges."
    },
    {
      icon: Globe,
      title: "Digital Platforms",
      description: "Scalable digital platforms that enhance customer experience and operational efficiency."
    },
    {
      icon: Shield,
      title: "Cyber Security & Privacy",
      description: "Comprehensive security solutions to protect your digital assets and ensure compliance."
    },
    {
      icon: Cloud,
      title: "Cloud Services",
      description: "Cloud migration and optimization services to accelerate your digital transformation."
    },
    {
      icon: Settings,
      title: "Managed IT Services",
      description: "Reliable IT infrastructure management to keep your business running smoothly."
    }
  ];

  return (
    <section id="services" className="py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground">
            Our Services
          </h2>
          <div className="w-16 h-1 bg-accent mx-auto"></div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Comprehensive digital solutions designed to accelerate your transformation journey and unlock new possibilities for growth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-elegant transition-all duration-300 hover:-translate-y-2 bg-card border-border">
              <CardHeader className="space-y-4">
                <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center group-hover:shadow-glow transition-all duration-300">
                  <service.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-xl font-semibold text-card-foreground group-hover:text-primary transition-colors duration-300">
                  {service.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground group">
            Explore All Services
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Services;