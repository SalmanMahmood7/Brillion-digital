import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";
import heroPattern from "@/assets/hero-pattern.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-background to-secondary/30"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                <span className="text-primary block">Harnessing</span>
                <span className="text-primary block">what's now.</span>
                <span className="text-foreground block">Imagining</span>
                <span className="text-foreground block">what's next.</span>
              </h1>
              
              <div className="w-16 h-1 bg-accent"></div>
              
              <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
                Guiding, protecting, and empowering organizations along their digital journey.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="bg-accent hover:bg-accent/90 text-accent-foreground group"
              >
                What we do
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground group"
              >
                <Play className="mr-2 h-4 w-4 transition-transform group-hover:scale-110" />
                Watch our story
              </Button>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative">
            <div className="relative">
              {/* Main Image Container */}
              <div className="relative bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl overflow-hidden shadow-elegant">
                <img
                  src={heroPattern}
                  alt="Digital transformation visualization"
                  className="w-full h-[500px] lg:h-[600px] object-cover"
                />
                
                {/* Overlay Gradient */}
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent"></div>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-primary rounded-2xl shadow-glow animate-pulse"></div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-accent rounded-xl shadow-elegant"></div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Geometric Background Elements */}
      <div className="absolute top-1/4 left-10 w-2 h-2 bg-primary rounded-full opacity-60 animate-pulse"></div>
      <div className="absolute top-1/3 right-20 w-3 h-3 bg-accent rounded-full opacity-40 animate-pulse"></div>
      <div className="absolute bottom-1/4 left-1/4 w-1 h-1 bg-primary rounded-full opacity-80 animate-pulse"></div>
    </section>
  );
};

export default Hero;