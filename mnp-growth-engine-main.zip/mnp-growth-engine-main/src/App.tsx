import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Services from "./pages/Services";
import About from "./pages/About";
import Work from "./pages/Work";
import Insights from "./pages/Insights";
import Contact from "./pages/Contact";
import Careers from "./pages/Careers";
import DigitalAdvisory from "./pages/services/DigitalAdvisory";
import AppliedDataAnalytics from "./pages/services/AppliedDataAnalytics";
import ApplicationDevelopment from "./pages/services/ApplicationDevelopment";
import DigitalPlatforms from "./pages/services/DigitalPlatforms";
import CyberSecurity from "./pages/services/CyberSecurity";
import CloudServices from "./pages/services/CloudServices";
import ManagedITServices from "./pages/services/ManagedITServices";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/services" element={<Services />} />
          <Route path="/about" element={<About />} />
          <Route path="/work" element={<Work />} />
          <Route path="/insights" element={<Insights />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/services/digital-advisory" element={<DigitalAdvisory />} />
          <Route path="/services/applied-data-analytics" element={<AppliedDataAnalytics />} />
          <Route path="/services/application-development" element={<ApplicationDevelopment />} />
          <Route path="/services/digital-platforms" element={<DigitalPlatforms />} />
          <Route path="/services/cyber-security-privacy" element={<CyberSecurity />} />
          <Route path="/services/cloud-services" element={<CloudServices />} />
          <Route path="/services/managed-it-services" element={<ManagedITServices />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
