import PageLayout from "@/components/PageLayout";
import { Card, CardContent } from "@/components/ui/card";
import aboutBg from "@/assets/about-bg.jpg";

const About = () => {
  return (
    <PageLayout>
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <section className="relative py-24 overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left Visual */}
              <div className="relative">
                <div className="relative bg-gradient-hero rounded-2xl overflow-hidden shadow-elegant">
                  <img
                    src={aboutBg}
                    alt="About us visualization"
                    className="w-full h-[400px] lg:h-[500px] object-cover opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/60 to-transparent"></div>
                  <div className="absolute inset-0 flex items-center p-8 lg:p-12">
                    <div className="space-y-6 text-white">
                      <h1 className="text-4xl lg:text-5xl font-bold">About us</h1>
                      <div className="w-16 h-1 bg-accent"></div>
                      <p className="text-lg leading-relaxed">
                        You have a vision for your future. We'll help you get there.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Content */}
              <div className="space-y-8">
                <div className="space-y-6">
                  <p className="text-lg text-foreground leading-relaxed">
                    No matter where you are on your digital journey, it's never too early to innovate. From meeting fast-changing customer demands to streamlining operations, being driven by the right digital strategy and fueled by the right technology is critical to helping you get ahead – and stay ahead.
                  </p>
                  
                  <p className="text-lg leading-relaxed">
                    <span className="font-semibold text-foreground">That's where we come in.</span> <span className="text-muted-foreground">Our experienced experts work closely with you to understand your organization's challenges and goals and then solution seamlessly as an extension of your team. With our specific industry and technical know-how, we provide capabilities and perspective that you won't find anywhere else, allowing you to get the most out of your digital investments.</span>
                  </p>

                  <p className="text-lg text-muted-foreground leading-relaxed">
                    So, whether you're taking your first digital steps or you're an industry trailblazer, if you have the will, we'll light the way.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-24 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-foreground">We succeed when you succeed</h2>
              </div>
              
              <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card className="bg-background border-border">
                  <CardContent className="p-8 space-y-4">
                    <div className="text-accent text-4xl font-bold">01</div>
                    <div className="w-12 h-1 bg-accent"></div>
                    <h3 className="text-xl font-semibold text-foreground">
                      A people-first approach to digital transformation.
                    </h3>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-primary text-primary-foreground border-0">
                  <CardContent className="p-8 space-y-4">
                    <div className="text-accent text-4xl font-bold">02</div>
                    <div className="w-12 h-1 bg-accent"></div>
                    <h3 className="text-xl font-semibold">
                      We're invested in the success of every project.
                    </h3>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </div>
    </PageLayout>
  );
};

export default About;