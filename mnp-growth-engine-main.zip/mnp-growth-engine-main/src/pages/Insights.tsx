import PageLayout from "@/components/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, User, ArrowRight } from "lucide-react";

const Insights = () => {
  const articles = [
    {
      title: "How to get your whole team using Microsoft 365",
      excerpt: "Discover strategies to drive adoption and maximize the value of your Microsoft 365 investment across your entire organization.",
      category: "Digital Transformation",
      author: "MNP Digital Team",
      date: "March 15, 2024",
      readTime: "5 min read"
    },
    {
      title: "The Future of Cloud Security in 2024",
      excerpt: "Explore the latest trends and best practices in cloud security to protect your digital assets in an evolving threat landscape.",
      category: "Cyber Security",
      author: "Security Experts",
      date: "March 10, 2024",
      readTime: "7 min read"
    },
    {
      title: "Data Analytics: Turning Insights into Action",
      excerpt: "Learn how to transform raw data into actionable business intelligence that drives growth and competitive advantage.",
      category: "Data & Analytics",
      author: "Analytics Team",
      date: "March 5, 2024",
      readTime: "6 min read"
    },
    {
      title: "Digital Platform Modernization: A Strategic Guide",
      excerpt: "Step-by-step approach to modernizing your digital platforms for improved performance and user experience.",
      category: "Digital Platforms",
      author: "Platform Specialists",
      date: "February 28, 2024",
      readTime: "8 min read"
    },
    {
      title: "Cloud Migration Best Practices",
      excerpt: "Essential strategies and considerations for a successful cloud migration that minimizes risks and maximizes benefits.",
      category: "Cloud Services",
      author: "Cloud Team",
      date: "February 25, 2024",
      readTime: "6 min read"
    },
    {
      title: "Building Resilient IT Infrastructure",
      excerpt: "How to create robust, scalable IT infrastructure that supports business growth and operational excellence.",
      category: "Managed IT",
      author: "Infrastructure Team",
      date: "February 20, 2024",
      readTime: "5 min read"
    }
  ];

  const categories = [
    "All Articles",
    "Digital Transformation", 
    "Cyber Security",
    "Data & Analytics",
    "Cloud Services",
    "Digital Platforms",
    "Managed IT"
  ];

  return (
    <PageLayout>
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <section className="relative py-24 bg-gradient-to-br from-background to-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center space-y-6">
              <h1 className="text-4xl lg:text-5xl font-bold text-foreground">
                Insights
              </h1>
              <div className="w-16 h-1 bg-accent mx-auto"></div>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Stay ahead of the curve with expert insights, industry trends, and practical guidance on digital transformation.
              </p>
            </div>
          </div>
        </section>

        {/* Filter Section */}
        <section className="py-16 bg-background border-b border-border">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map((category, index) => (
                <Badge 
                  key={index} 
                  variant={index === 0 ? "default" : "secondary"}
                  className={`px-4 py-2 text-sm font-medium cursor-pointer transition-colors duration-200 ${
                    index === 0 
                      ? "bg-primary text-primary-foreground hover:bg-primary/90" 
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>
        </section>

        {/* Articles Grid */}
        <section className="py-24 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {articles.map((article, index) => (
                <Card key={index} className="group hover:shadow-elegant transition-all duration-300 hover:-translate-y-2 bg-card border-border h-full flex flex-col">
                  <CardHeader className="space-y-4 flex-1">
                    <Badge variant="secondary" className="w-fit text-xs">
                      {article.category}
                    </Badge>
                    <CardTitle className="text-xl font-semibold text-card-foreground group-hover:text-primary transition-colors duration-300 line-clamp-2">
                      {article.title}
                    </CardTitle>
                    <p className="text-muted-foreground leading-relaxed line-clamp-3">
                      {article.excerpt}
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4 pt-0">
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{article.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>{article.date}</span>
                        </div>
                      </div>
                      <span>{article.readTime}</span>
                    </div>
                    <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0 h-auto group/btn w-full justify-start">
                      <span className="flex items-center">
                        Read more
                        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                      </span>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center mt-16">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                Load More Articles
              </Button>
            </div>
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="py-24 bg-gradient-hero">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground">
                Stay informed with our newsletter
              </h2>
              <p className="text-lg text-primary-foreground/80 leading-relaxed">
                Get the latest insights, industry trends, and expert guidance delivered to your inbox monthly.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-3 rounded-lg border border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground placeholder:text-primary-foreground/60 focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </PageLayout>
  );
};

export default Insights;