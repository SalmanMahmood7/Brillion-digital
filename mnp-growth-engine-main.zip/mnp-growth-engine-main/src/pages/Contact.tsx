import PageLayout from "@/components/PageLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import contactBg from "@/assets/contact-bg.jpg";

const Contact = () => {
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message sent!",
      description: "Thank you for your message. We'll get back to you soon.",
    });
  };

  return (
    <PageLayout>
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <section className="relative py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background to-secondary/30"></div>
          
          <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left Content */}
              <div className="space-y-8">
                <div className="space-y-6">
                  <h1 className="text-4xl lg:text-5xl font-bold text-foreground">
                    Contact us
                  </h1>
                  
                  <div className="w-16 h-1 bg-accent"></div>
                  
                  <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
                    Let us know who you are and how we can assist and someone from our team will be in touch.
                  </p>
                </div>
              </div>

              {/* Right Visual */}
              <div className="relative">
                <div className="relative bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl overflow-hidden shadow-elegant">
                  <img
                    src={contactBg}
                    alt="Contact visualization"
                    className="w-full h-[400px] lg:h-[500px] object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-24 bg-secondary/30">
          <div className="max-w-4xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Form */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-2xl font-semibold text-card-foreground">
                    How can we help?
                  </CardTitle>
                  <p className="text-muted-foreground">
                    We're here to answer your questions.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    * indicates required field
                  </p>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-sm font-medium">
                        Email *
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        required
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-sm font-medium">
                        Full Name *
                      </Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Enter your full name"
                        required
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="company" className="text-sm font-medium">
                        Company
                      </Label>
                      <Input
                        id="company"
                        type="text"
                        placeholder="Enter your company name"
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-sm font-medium">
                        Phone Number
                      </Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="Enter your phone number"
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message" className="text-sm font-medium">
                        How can we help you? *
                      </Label>
                      <Textarea
                        id="message"
                        placeholder="Tell us about your project or question..."
                        required
                        className="w-full min-h-[120px]"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                    >
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <div className="space-y-8">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold text-card-foreground">
                      Get in Touch
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium text-foreground">Phone</h4>
                      <p className="text-muted-foreground">1-800-MNP-DIGITAL</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground">Email</h4>
                      <p className="text-muted-foreground">hello@mnpdigital.ca</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground">Locations</h4>
                      <p className="text-muted-foreground">Offices across Canada</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-primary text-primary-foreground border-0">
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold">
                      Ready to transform?
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="mb-4 text-primary-foreground/90">
                      Let's discuss how we can guide your organization through its digital transformation journey.
                    </p>
                    <Button variant="secondary" size="sm">
                      Schedule a Call
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </div>
    </PageLayout>
  );
};

export default Contact;