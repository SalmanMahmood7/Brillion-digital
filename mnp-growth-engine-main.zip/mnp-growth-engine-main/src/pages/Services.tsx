import PageLayout from "@/components/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Brain, 
  BarChart3, 
  Code, 
  Globe, 
  Shield, 
  Cloud,
  Settings,
  ArrowRight
} from "lucide-react";
import servicesBg from "@/assets/services-bg.jpg";

const Services = () => {
  const services = [
    {
      icon: Brain,
      title: "Digital Advisory",
      description: "Understand, anticipate, and accelerate with confidence.",
      href: "/services/digital-advisory"
    },
    {
      icon: BarChart3,
      title: "Applied Data & Analytics", 
      description: "Transform raw data into actionable insights that drive business growth.",
      href: "/services/applied-data-analytics"
    },
    {
      icon: Code,
      title: "Application Development",
      description: "Custom applications built with modern technologies to solve unique challenges.",
      href: "/services/application-development"
    },
    {
      icon: Globe,
      title: "Digital Platforms",
      description: "Boost growth and productivity using ERP, CRM, and CMS platforms.",
      href: "/services/digital-platforms"
    },
    {
      icon: Shield,
      title: "Cyber Security & Privacy",
      description: "Minimize threats and proactively protect your most valuable assets.",
      href: "/services/cyber-security-privacy"
    },
    {
      icon: Cloud,
      title: "Cloud Services",
      description: "Cloud migration and optimization services to accelerate transformation.",
      href: "/services/cloud-services"
    },
    {
      icon: Settings,
      title: "Managed IT Services",
      description: "Reliable IT infrastructure management to keep your business running smoothly.",
      href: "/services/managed-it-services"
    }
  ];

  return (
    <PageLayout>
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <section className="relative py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background to-secondary/30"></div>
          
          <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left Content */}
              <div className="space-y-8">
                <div className="space-y-6">
                  <h1 className="text-4xl lg:text-5xl font-bold text-foreground">
                    Services
                  </h1>
                  
                  <div className="w-16 h-1 bg-accent"></div>
                  
                  <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
                    Our scalable team of expert advisors, problem solvers, and builders ensure you receive the specific skills and guidance you need to succeed.
                  </p>
                </div>
              </div>

              {/* Right Visual */}
              <div className="relative">
                <div className="relative bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl overflow-hidden shadow-elegant">
                  <img
                    src={servicesBg}
                    alt="Services visualization"
                    className="w-full h-[400px] lg:h-[500px] object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-24 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <Card key={index} className="group hover:shadow-elegant transition-all duration-300 hover:-translate-y-2 bg-card border-border">
                  <CardHeader className="space-y-4">
                    <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center group-hover:shadow-glow transition-all duration-300">
                      <service.icon className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-xl font-semibold text-card-foreground group-hover:text-primary transition-colors duration-300">
                      {service.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground leading-relaxed">
                      {service.description}
                    </p>
                    <Button variant="ghost" size="sm" asChild className="text-primary hover:text-primary/90 p-0 h-auto group/btn">
                      <a href={service.href} className="flex items-center">
                        Learn more
                        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </div>
    </PageLayout>
  );
};

export default Services;