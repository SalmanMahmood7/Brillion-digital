import PageLayout from "@/components/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import workBg from "@/assets/work-bg.jpg";

const Work = () => {
  const serviceFilters = [
    "ALL",
    "APPLICATION DEVELOPMENT", 
    "APPLIED DATA & ANALYTICS",
    "CLOUD SERVICES",
    "CYBER SECURITY & PRIVACY", 
    "DIGITAL ADVISORY",
    "DIGITAL PLATFORMS",
    "MANAGED IT SERVICES"
  ];

  const caseStudies = [
    {
      title: "MaRS Discovery District",
      description: "An infrastructure revamp increases efficiency",
      category: "MANAGED IT SERVICES"
    },
    {
      title: "Canadian Supplier of Propane Products and Services",
      description: "Consolidating data and discovering multi-channel sales opportunities",
      category: "APPLIED DATA & ANALYTICS"
    },
    {
      title: "Rypl.com",
      description: "Consolidating data and discovering multi-channel sales opportunities",
      category: "APPLICATION DEVELOPMENT"
    }
  ];

  return (
    <PageLayout>
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <section className="relative py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background to-secondary/30"></div>
          
          <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left Content */}
              <div className="space-y-8">
                <div className="space-y-6">
                  <h1 className="text-4xl lg:text-5xl font-bold text-foreground">
                    Work
                  </h1>
                  
                  <div className="w-16 h-1 bg-accent"></div>
                  
                  <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
                    We're driven to produce results regardless of your sector or size. We bring relevant industry and technical know-how to help you succeed now, and in the future. Here's how we've done it for other clients.
                  </p>
                </div>
              </div>

              {/* Right Visual */}
              <div className="relative">
                <div className="relative bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl overflow-hidden shadow-elegant">
                  <img
                    src={workBg}
                    alt="Work portfolio visualization"
                    className="w-full h-[400px] lg:h-[500px] object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Filter Section */}
        <section className="py-16 bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="flex flex-wrap gap-3 justify-center">
              {serviceFilters.map((filter, index) => (
                <Badge 
                  key={index} 
                  variant={index === 0 ? "default" : "secondary"}
                  className={`px-4 py-2 text-sm font-medium cursor-pointer transition-colors duration-200 ${
                    index === 0 
                      ? "bg-primary text-primary-foreground hover:bg-primary/90" 
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                >
                  {filter}
                </Badge>
              ))}
            </div>
          </div>
        </section>

        {/* Case Studies */}
        <section className="py-24 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {caseStudies.map((study, index) => (
                <Card key={index} className="group hover:shadow-elegant transition-all duration-300 hover:-translate-y-2 bg-card border-border">
                  <CardHeader className="space-y-4">
                    <Badge variant="secondary" className="w-fit text-xs">
                      {study.category}
                    </Badge>
                    <CardTitle className="text-xl font-semibold text-card-foreground group-hover:text-primary transition-colors duration-300">
                      {study.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground leading-relaxed">
                      {study.description}
                    </p>
                    <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0 h-auto">
                      Read case study →
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center mt-16">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                View All Case Studies
              </Button>
            </div>
          </div>
        </section>
      </div>
    </PageLayout>
  );
};

export default Work;