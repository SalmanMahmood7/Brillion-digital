import PageLayout from "@/components/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, ArrowRight } from "lucide-react";

const Careers = () => {
  const jobOpenings = [
    {
      title: "Senior Digital Transformation Consultant",
      department: "Digital Advisory",
      location: "Toronto, ON",
      type: "Full-time",
      description: "Lead digital transformation initiatives for enterprise clients, providing strategic guidance and implementation support.",
      posted: "2 days ago"
    },
    {
      title: "Cloud Solutions Architect",
      department: "Cloud Services",
      location: "Vancouver, BC",
      type: "Full-time",
      description: "Design and implement scalable cloud solutions for clients across various industries.",
      posted: "1 week ago"
    },
    {
      title: "Cybersecurity Analyst",
      department: "Cyber Security & Privacy",
      location: "Calgary, AB",
      type: "Full-time",
      description: "Assess security risks, implement protective measures, and ensure compliance with industry standards.",
      posted: "3 days ago"
    },
    {
      title: "Data Analytics Specialist",
      department: "Applied Data & Analytics",
      location: "Montreal, QC",
      type: "Full-time",
      description: "Transform client data into actionable insights using advanced analytics and visualization tools.",
      posted: "5 days ago"
    },
    {
      title: "Application Developer",
      department: "Application Development",
      location: "Remote",
      type: "Full-time",
      description: "Develop custom applications using modern frameworks and best practices in software development.",
      posted: "1 day ago"
    },
    {
      title: "IT Infrastructure Manager",
      department: "Managed IT Services",
      location: "Ottawa, ON",
      type: "Full-time",
      description: "Oversee IT infrastructure for multiple clients, ensuring optimal performance and security.",
      posted: "1 week ago"
    }
  ];

  const benefits = [
    {
      title: "Competitive Compensation",
      description: "Industry-leading salary and performance-based bonuses"
    },
    {
      title: "Professional Development", 
      description: "Continuous learning opportunities and certification support"
    },
    {
      title: "Flexible Work",
      description: "Hybrid and remote work options with flexible schedules"
    },
    {
      title: "Health & Wellness",
      description: "Comprehensive health benefits and wellness programs"
    },
    {
      title: "Innovation Culture",
      description: "Work with cutting-edge technology and innovative solutions"
    },
    {
      title: "Team Environment",
      description: "Collaborative culture with talented professionals"
    }
  ];

  return (
    <PageLayout>
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <section className="relative py-24 bg-gradient-to-br from-background to-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center space-y-6">
              <h1 className="text-4xl lg:text-5xl font-bold text-foreground">
                Careers
              </h1>
              <div className="w-16 h-1 bg-accent mx-auto"></div>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Join our team of digital transformation experts and help organizations harness what's now while imagining what's next.
              </p>
            </div>
          </div>
        </section>

        {/* Why Join Us */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center space-y-6 mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground">
                Why Join MNP Digital?
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Be part of a dynamic team that's shaping the future of digital transformation across Canada.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {benefits.map((benefit, index) => (
                <Card key={index} className="bg-card border-border hover:shadow-elegant transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-card-foreground">
                      {benefit.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      {benefit.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Job Openings */}
        <section className="py-24 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center space-y-6 mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground">
                Current Opportunities
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Discover exciting career opportunities across our various service areas.
              </p>
            </div>

            <div className="space-y-6">
              {jobOpenings.map((job, index) => (
                <Card key={index} className="group hover:shadow-elegant transition-all duration-300 bg-card border-border">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                      <div className="space-y-3 flex-1">
                        <div className="flex flex-wrap items-center gap-3">
                          <Badge variant="secondary" className="text-xs">
                            {job.department}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {job.type}
                          </Badge>
                        </div>
                        
                        <h3 className="text-xl font-semibold text-card-foreground group-hover:text-primary transition-colors duration-300">
                          {job.title}
                        </h3>
                        
                        <p className="text-muted-foreground leading-relaxed">
                          {job.description}
                        </p>
                        
                        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-4 w-4" />
                            <span>{job.location}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>Posted {job.posted}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-shrink-0">
                        <Button className="bg-accent hover:bg-accent/90 text-accent-foreground group/btn">
                          Apply Now
                          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center mt-12">
              <p className="text-muted-foreground mb-6">
                Don't see the right role? We're always looking for talented individuals.
              </p>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                Submit General Application
              </Button>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-24 bg-gradient-hero">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground">
                Ready to shape the future of digital transformation?
              </h2>
              <p className="text-lg text-primary-foreground/80 leading-relaxed">
                Join our team and help organizations across Canada harness technology to achieve their goals.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  View All Positions
                </Button>
                <Button size="lg" variant="secondary">
                  Learn About Our Culture
                </Button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </PageLayout>
  );
};

export default Careers;