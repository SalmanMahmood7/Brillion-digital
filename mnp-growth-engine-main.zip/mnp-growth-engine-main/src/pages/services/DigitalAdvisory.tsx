import PageLayout from "@/components/PageLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, CheckCircle, ArrowRight } from "lucide-react";

const DigitalAdvisory = () => {
  const capabilities = [
    "Digital Strategy Development",
    "Technology Assessment", 
    "Digital Transformation Roadmapping",
    "Change Management",
    "Digital Maturity Assessments",
    "Innovation Consulting"
  ];

  return (
    <PageLayout>
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <section className="relative py-24 bg-gradient-to-br from-background to-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center shadow-glow">
                  <Brain className="h-8 w-8 text-primary-foreground" />
                </div>
                <div className="space-y-6">
                  <h1 className="text-4xl lg:text-5xl font-bold text-foreground">
                    Digital Advisory
                  </h1>
                  <div className="w-16 h-1 bg-accent"></div>
                  <p className="text-xl text-muted-foreground leading-relaxed">
                    Understand, anticipate, and accelerate with confidence.
                  </p>
                </div>
              </div>
              <div className="relative">
                <div className="bg-gradient-hero rounded-2xl p-8 lg:p-12 shadow-elegant">
                  <h2 className="text-2xl font-bold text-primary-foreground mb-4">
                    Strategic Digital Guidance
                  </h2>
                  <p className="text-primary-foreground/80 leading-relaxed">
                    Navigate your digital transformation journey with expert advisory services that align technology investments with business objectives.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Capabilities */}
        <section className="py-24 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center space-y-6 mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground">
                Our Capabilities
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Comprehensive advisory services to guide your digital transformation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {capabilities.map((capability, index) => (
                <Card key={index} className="bg-card border-border hover:shadow-elegant transition-all duration-300">
                  <CardContent className="p-6 flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                    <span className="text-card-foreground font-medium">{capability}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 bg-gradient-hero">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground">
                Ready to accelerate your digital transformation?
              </h2>
              <p className="text-lg text-primary-foreground/80">
                Let our digital advisory experts guide your journey.
              </p>
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground group">
                Get Started
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>
          </div>
        </section>
      </div>
    </PageLayout>
  );
};

export default DigitalAdvisory;